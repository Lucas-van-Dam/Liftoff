﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GXPEngine
{
    public static class Enums
    {
        public enum players
        {
            player1 = 1,
            player2 = 2
        }

        public enum characters
        {
            fireGirl,
            fatGuy,
            rootsGuy
        }
    }
}
