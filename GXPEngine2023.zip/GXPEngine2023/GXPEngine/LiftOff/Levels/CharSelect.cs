﻿using System;
using GXPEngine.Core;

namespace GXPEngine
{
    public class CharSelect : Level
    {
        Enums.characters player1;

        bool player1Selected = false;

        Enums.characters player2;

        bool player2Selected = false;

        bool player1Changed;
        bool player2Changed;

        public CharSelect(string filename, int cols, int rows, int numOfFrames) : base(filename, cols, rows, numOfFrames)
        {
        }

        void Update()
        {
            if(player1Selected && player2Selected)
            {
                game.LoadGameLevel(player1, player2);
            }

            if (ArduinoInput.GetAxisHorizontal(Enums.players.player1) == 1 || Input.GetKey(Key.D) && !player1Changed && !player1Selected)
            {
                switch (player1)
                {
                    case Enums.characters.fireGirl:
                        player1 = Enums.characters.fatGuy;
                        break;

                    case Enums.characters.fatGuy:
                        player1 = Enums.characters.rootsGuy;
                        break;

                    case Enums.characters.rootsGuy:
                        player1 = Enums.characters.fireGirl;
                        break;
                }
                player1Changed = true;
            }

            if (ArduinoInput.GetAxisHorizontal(Enums.players.player1) == -1 || Input.GetKey(Key.A) && !player1Changed && !player1Selected)
            {
                switch (player1)
                {
                    case Enums.characters.fireGirl:
                        player1 = Enums.characters.rootsGuy;
                        break;

                    case Enums.characters.fatGuy:
                        player1 = Enums.characters.fireGirl;
                        break;

                    case Enums.characters.rootsGuy:
                        player1 = Enums.characters.fatGuy;
                        break;
                }
                player1Changed = true;
            }

            if (ArduinoInput.GetAxisHorizontal(Enums.players.player2) == -1 || Input.GetKey(Key.LEFT) && !player2Changed && !player2Selected)
            {
                switch (player2)
                {
                    case Enums.characters.fireGirl:
                        player2 = Enums.characters.rootsGuy;
                        break;

                    case Enums.characters.fatGuy:
                        player2 = Enums.characters.fireGirl;
                        break;

                    case Enums.characters.rootsGuy:
                        player2 = Enums.characters.fatGuy;
                        break;
                }
                player2Changed = true;
            }

            if (ArduinoInput.GetAxisHorizontal(Enums.players.player2) == 1 || Input.GetKey(Key.RIGHT) && !player2Changed && !player2Selected)
            {
                switch (player2)
                {
                    case Enums.characters.fireGirl:
                        player2 = Enums.characters.fatGuy;
                        break;

                    case Enums.characters.fatGuy:
                        player2 = Enums.characters.rootsGuy;
                        break;

                    case Enums.characters.rootsGuy:
                        player2 = Enums.characters.fireGirl;
                        break;
                }

                player2Changed = true;
            }

            if (ArduinoInput.GetAxisHorizontal(Enums.players.player1) == 0 || Input.GetKeyUp(Key.A) || Input.GetKeyUp(Key.D))
            {
                player1Changed = false;
            }
            if (ArduinoInput.GetAxisHorizontal(Enums.players.player2) == 0 || Input.GetKeyUp(Key.LEFT) || Input.GetKeyUp(Key.RIGHT))
            {
                player1Changed = false;
            }

            if(/*ArduinoInput.GetButtonDown("B1", Enums.players.player1)*/ Input.GetKeyDown(Key.LEFT_SHIFT))
            {
                player1Selected = !player1Selected;
            }

            if (/*ArduinoInput.GetButtonDown("B1", Enums.players.player2)*/ Input.GetKeyDown(Key.RIGHT_SHIFT))
            {
                player2Selected = !player2Selected;
            }
        }
    }
}
