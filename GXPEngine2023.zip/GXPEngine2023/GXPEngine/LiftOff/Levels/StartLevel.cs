﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GXPEngine
{
    public class StartLevel : Level
    {
        EasyDraw StartButton;

        EasyDraw OptionsButton;

        EasyDraw selectedButton;

        bool changedButtons;

        public StartLevel(string filename, int cols, int rows, int numOfFrames) : base(filename, cols, rows, numOfFrames)
        {
            StartButton = new EasyDraw(260, 97);
            StartButton.SetXY(width / 2 - 140, height / 2 -50);
            StartButton.Clear(255, 255, 255, alpha: 55);
            AddChild(StartButton);

            OptionsButton = new EasyDraw(260, 97);
            OptionsButton.SetXY(width / 2 - 140, height / 2 + 90);
            OptionsButton.Clear(255, 255, 255, alpha: 100);
            AddChild(OptionsButton);
            selectedButton = StartButton;
        }

        void Update()
        {
            if(ArduinoInput.GetAxisVertical(Enums.players.player1) == 1 || ArduinoInput.GetAxisVertical(Enums.players.player1) == -1 || Input.GetKey(Key.UP) || Input.GetKey(Key.DOWN))
            {
                if (changedButtons)
                {
                    return;
                }
                if(selectedButton == StartButton)
                {
                    selectedButton = OptionsButton;
                }
                else
                {
                    selectedButton = StartButton;
                }
                changedButtons = true;
            }

            if(OptionsButton == selectedButton)
            {
                OptionsButton.alpha = 100;
                StartButton.alpha = 0;
            }
            else
            {
                OptionsButton.alpha = 0;
                StartButton.alpha = 100;
            }

            if (Input.GetKeyUp(Key.UP) || Input.GetKeyUp(Key.DOWN))
            {
                changedButtons = false;
            }
            if(ArduinoInput.GetAxisVertical(Enums.players.player1) == 0)
            {
                changedButtons = false;
            }

            if (Input.GetKeyDown(Key.ENTER))
            {
                if(selectedButton == StartButton)
                {
                    game.LoadNextLevel();
                }
            }


            base.Update();

        }
    }
}
